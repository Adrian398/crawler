# FutureKids --------------------------------------------------------------

tryCatch( { 
  
  fututoFuturo <- function(url) {
    
    
    futureVeranstalter = futureDatumVon = futureDatumBis = futureStartzeit = futureEndzeit = futureTitel = futureBeschreibung = 
      futureAdresse = futurePLZ = futureOrtsname = futureLat = futureLong = futureLink = futureEintritt = NA
    
    
    futureVeranstalter <- "Futurekids Computerkurse"
    
    futureDf <- data.frame()
    
    futureLink <- url
    
    futureLink %>% 
      read_html() -> futureURL
    
    futureURL %>% 
      html_nodes(".uk-accordion-title") %>% 
      html_text()-> futureKurstitelSammlung
    
    futureURL %>% 
      html_nodes(".uk-accordion-content") -> futureKurse
    
    "http://www.futurekids-wue.de/ueber-uns.html" %>% 
      read_html() %>% 
      html_nodes(".extradiv") %>% 
      grep("970[0-9]{2} W", value = T, .) %>% 
      gsub("<.*?>", "", .) %>% 
      str_split("\\n") %>% 
      unlist() -> futureAnschrift
    
    futureAnschrift %>% 
      grep("([A-zöäü]+str.)|(Strasse)|(Straße)|(strasse)|(straße)", value = T,.) %>% 
      str_trim("both") -> futureAdresse 
    
    futureAnschrift %>% 
      grep("970[0-9]{2} W", value = T, .) %>%
      str_trim("both") %>% 
      #str_match("970[0-9]{2}")
      gsub("^(970[0-9]{2}) ([A-zü]*)", "\\1", .) -> futurePLZ
    
    futureAnschrift %>% 
      grep("970[0-9]{2} W", value = T, .) %>%
      str_trim("both") %>% 
      #str_match("970[0-9]{2}")
      gsub("^(970[0-9]{2}) ([A-zäöü]*)", "\\2", .) -> futureOrtsname
    
    preFutureVeranstaltrUndAdresse <- paste(futureVeranstalter, futureAdresse, futurePLZ, futureOrtsname, sep = ", ")
    
    futureLatAndLong <- geocode(preFutureVeranstaltrUndAdresse)
    
    futureLat <- futureLatAndLong[2]
    futureLong <- futureLatAndLong[1]
    
    
    for (n in 1:length(futureKurse)) {
      
      futureKurse[n] %>%  
        html_nodes(".agetimediv") %>% 
        html_text(trim = T) -> testObFixerTermin 
      
      if( any(grepl("(Mo\\. |Di\\. |Mi\\. |Do\\. |Fr\\. |Sa\\. |So\\.)[0-9]{2}\\.[0-9]{2}\\.[0-9]{2}", testObFixerTermin)) ){
        
        futureTitel <- futureKurstitelSammlung[n] %>% 
          as.character() %>% 
          noquote()
        
        testObFixerTermin %>% 
          str_split("\\n") %>% 
          #gsub("[[:space:]]{2,}", "", .) %>% 
          unlist() %>% 
          str_replace_all("[[:space:]]{2,}","") %>% 
          str_replace_all(" oder$", "") -> futureDatumUndAltersempfehlung
        
        futureDatumUndAltersempfehlung %>% 
          grep("(Mo\\. |Di\\. |Mi\\. |Do\\. |Fr\\. |Sa\\. |So\\.)[0-9]{2}\\.[0-9]{2}\\.[0-9]{2}", value = T,.) -> DatumsListeChar
        
        futureDatumUndAltersempfehlung %>% 
          grep("(Mo\\. |Di\\. |Mi\\. |Do\\. |Fr\\. |Sa\\. |So\\.)[0-9]{2}\\.[0-9]{2}\\.[0-9]{2}", value = T, invert = T, .) -> futureAltersempfehlung
        
        futureKurse[n] %>% 
          html_nodes("p") %>% 
          html_text(trim = T) %>% 
          gsub("  ", "",.) %>% 
          gsub("\\n", "",.) %>% 
          noquote() -> futurePreBeschreibung
        
        futureKurse[n] %>% 
          html_nodes("strong:nth-child(3)") %>% 
          html_text() %>% 
          str_replace_all("\\.- ", "\\.00 ") %>% 
          str_match_all("[0-9]{1,4}\\.[0-9]{2}") %>% 
          unlist() %>% 
          as.numeric() %>% 
          sum() %>% 
          as.character() -> futureEintritt
        
        for (variable in DatumsListeChar) {
          
          variable %>% 
            str_match("[0-9]{2}\\.[0-9]{2}\\.[0-9]{2}") %>% 
            as.Date("%d.%m.%y") -> futureDatumVon
          
          futureDatumBis <- futureDatumVon
          
          variable %>% 
            str_match("[0-9]{2}:[0-9]{2}.{1,4}[0-9]{2}:[0-9]{2}") %>%
            gsub("([0-9]{2}:[0-9]{2}) . ({1,4}[0-9]{2}:[0-9]{2})", "\\1",.) %>% 
            gsub(" ", "", .) %>% 
            as.character()-> futureStartzeit
          
          futureStartzeit <- times(paste0(futureStartzeit, ":00"))
          
          variable %>% 
            str_match("[0-9]{2}:[0-9]{2}.{1,4}[0-9]{2}:[0-9]{2}") %>% 
            gsub("([0-9]{2}:[0-9]{2}) . ({1,4}[0-9]{2}:[0-9]{2})", "\\2",.) %>% 
            gsub(" ", "", .) %>% 
            as.character()-> futureEndzeit
          
          futureEndzeit <- times(paste0(futureEndzeit, ":00"))
          
          futureBeschreibung <- paste(futureAltersempfehlung[1], futurePreBeschreibung, "Weiterfolgende Termine:", sep = ";  ") %>% as.character()
          futureBeschreibung <- paste(futureBeschreibung, variable, sep = " ") %>% as.character()
          
          futureDf2 <- data.frame(title = futureTitel, url = futureLink, description = futureBeschreibung, lng = futureLong, 
                                  lat = futureLat, city = futureOrtsname, street = futureAdresse, zip = futurePLZ, 
                                  date_start = futureDatumVon, date_end = futureDatumBis, time_start = futureStartzeit, 
                                  time_end = futureEndzeit, price = futureEintritt, organizer = futureVeranstalter, 
                                  stringsAsFactors = F)
          
          futureDf <- rbind(futureDf, futureDf2)
          
        }
        
        
      } 
      
    }
    futureDf
  }
  
  futureAlleLinks <- c("http://www.futurekids-wue.de/kids.html", "http://www.futurekids-wue.de/erwachsene.html")
  
  
  futureDfFINAL <- map_df(futureAlleLinks, fututoFuturo)
  
  colnames(futureDfFINAL) <- c("title", "url", "description", "lng", "lat", "city", "street", "zip", "date_start", "date_end", "time_start", "time_end", "price", "organizer")
  
  if( !all(is.na(futureDfFINAL$time_start)) ){
    futureDfFINAL$time_start <- times(futureDfFINAL$time_start)
  }
  if( !all(is.na(futureDfFINAL$time_end)) ){
    futureDfFINAL$time_end <- times(futureDfFINAL$time_end)
  }
  
  if(exists("futureDfFINAL")){
    if(length(futureDfFINAL) != 0 & ncol(futureDfFINAL) == 14){
      main_df <- rbind(main_df, futureDfFINAL)
    }
  }
  
}
, error = function(e) {})

