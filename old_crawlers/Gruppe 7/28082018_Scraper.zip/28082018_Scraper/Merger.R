library(rvest)
library(dplyr)
library(tidytext)
library(tidyverse)
library(stringr)
library(httr)
library(lubridate)
library(devtools)
library(RSelenium)
library(chron)
library(stringi)
#devtools::install_github("dkahle/ggmap") # wird benoetigt um die Funktion "register_google()" aufrufen zu koennen
library(ggmap)
library(feather)


########## DER FINALE DATAFRAME HEISST "main_df" ##########

main_df <- data.frame(title = character(), url = character(), description = character(), lng = numeric(), lat = numeric(), city = character(), 
                       street = character(), zip = numeric(), date_start = times(), date_end = times(), time_start = times(), 
                       time_end = times(), price = character(), organizer = character(), stringsAsFactors = F)

#Set working directory
#setwd("~/Desktop/Scraper")

#Deutsche Zeit
Sys.setlocale("LC_TIME", "de_DE") #MAC
#Sys.setlocale("LC_ALL","German") #WINDOWS


# API Key 1
register_google(key = "AIzaSyC_lvgZae1kGJ5QWEz2wz3ExZJmBbOzbZ4")

# Puppentheater Kasperhaus, Uniklinikum Würzburg, Evan.-Luth. Auferstehungskirche, Galerie Gabriele Müller
# 165, 166, 168, 170
# korrekte RSelenium Version installieren
# Out: Dataframes werden automatisch an den main_df angehaengt
source("165-170.R")



# API Key 2
register_google(key = "AIzaSyDOjGt9LQMihlMnknjDY49Qgwe2m_vqr9g")

# Standard, Labyrinth
# 159, 167
# Facebook Scraper: Universallösung funktioniert auch mit allen anderen Veranstaltern
# Links können im Scraper selektiert werden. Momentan: Standard & Labyrinth
# Out: Dataframes werden automatisch an den main_df angehaengt
source("facebook_159&167.R")
    


# Wuf Zentrum, Hofkeller, Krebsgesellschaft, Future Kids, Fischerzunft, Loma
# 173, 174, 175, 179, 180, 182
# !!! Hofkeller braucht sehr lange (~3min)
# Out: Dataframes werden automatisch an den main_df angehaengt
source("173&175&179-182.R") 
source("174.R")


# API Key 3
register_google(key = "AIzaSyBBlmECdS2894lj2y0l3qNfVeBKF79Lmik")

# Theater Spielberg, Burkardushaus, Buchladen Neuer Weg, Deutschhaus Gymnasium, Bürgerspital
# 160, 161, 163, 164, 178
# Out: Dataframes werden automatisch an den main_df angehaengt
source("160-164&178.R")



# Redundanzen beseitigen
main_df <- unique(main_df)

# Ersetzen aller Umlaute
for(i in c(1,3,6,7,14)){
  main_df[,i] <- stringi::stri_replace_all_fixed(main_df[,i],c("Ü","ü","Ö","ö","Ä","ä","ß"), c("Ue","ue","Oe","oe","Ae","ae","ss"),vectorize_all = F)
}

# Zeilennamen anpassen
row.names(main_df) <- c(1:nrow(main_df))

# Delete Cache
#rm(list = setdiff(ls(), "main_df"))

# set datatypes
main_df$title <- as.character(main_df$title)
main_df$url <- as.character(main_df$url)
main_df$description <- as.character(main_df$description)
main_df$lat <- as.numeric(main_df$lat)
main_df$lng <- as.numeric(main_df$lng)
main_df$city <- as.character(main_df$city)
main_df$street <- as.character(main_df$street)
main_df$zip <- as.numeric(main_df$zip)
main_df$date_start <- as.Date(main_df$date_start)
main_df$date_end <- as.Date(main_df$date_end)
main_df$time_start <- times(main_df$time_start)
main_df$time_end <- times(main_df$time_end)
main_df$price <- as.character(main_df$price)
main_df$organizer <- as.character(main_df$organizer)

########## DER FINALE DATAFRAME HEISST "main_df" ##########

# Write feather
write_feather(main_df, "all_events")

# Save as .csv
#write.table(main_df, file="all_events.csv", row.names=F, col.names= T,sep =",")
#View(main_df)
